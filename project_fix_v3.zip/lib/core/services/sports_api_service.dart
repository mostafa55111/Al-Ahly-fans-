import 'package:http/http.dart' as http;
import 'dart:convert';

class SportsApiService {
  // TheSportDB API Configuration
  static const String theSportsDbUrl = 'http://www.thesportsdb.com/api/v1/json/3';
  static const String ahlyTeamId = '138995'; // ID الأهلي (Al Ahly Cairo)
  
  // Football API Configuration
  static const String footballApiUrl = 'https://api.football-data.org/v4';
  static const String footballApiKey = '8c16585903c335eb82435488feac3937';
  static const String ahlyTeamIdFootballApi = '674'; // ID الأهلي في Football API

  /// جلب معلومات الفريق من TheSportDB
  Future<Map<String, dynamic>?> getTeamInfo() async {
    try {
      final response = await http.get(
        Uri.parse('$theSportsDbUrl/lookupteam.php?id=$ahlyTeamId'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['teams'] != null && data['teams'].isNotEmpty) {
          return data['teams'][0];
        }
      }
      return null;
    } catch (e) {
      print('خطأ في جلب معلومات الفريق: $e');
      return null;
    }
  }

  /// جلب المباريات القادمة من Football API (أكثر دقة)
  Future<List<Map<String, dynamic>>> getNextMatches() async {
    try {
      // محاولة جلب من Football API أولاً
      final footballMatches = await _getNextMatchesFromFootballApi();
      if (footballMatches.isNotEmpty) {
        return footballMatches;
      }
      
      // إذا فشل، استخدم TheSportDB
      return await _getNextMatchesFromTheSportDB();
    } catch (e) {
      print('خطأ في جلب المباريات القادمة: $e');
      return [];
    }
  }

  /// جلب المباريات القادمة من Football API
  Future<List<Map<String, dynamic>>> _getNextMatchesFromFootballApi() async {
    try {
      final response = await http.get(
        Uri.parse('$footballApiUrl/teams/$ahlyTeamIdFootballApi/matches?status=SCHEDULED'),
        headers: {'X-Auth-Token': footballApiKey},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['matches'] != null) {
          return List<Map<String, dynamic>>.from(
            (data['matches'] as List).map((match) => {
              'id': match['id'],
              'utcDate': match['utcDate'],
              'status': match['status'],
              'homeTeam': match['homeTeam']['name'],
              'awayTeam': match['awayTeam']['name'],
              'homeTeamId': match['homeTeam']['id'],
              'awayTeamId': match['awayTeam']['id'],
              'competition': match['competition']['name'],
              'venue': match['venue'] ?? 'ملعب غير محدد',
            })
          );
        }
      }
      return [];
    } catch (e) {
      print('خطأ في Football API: $e');
      return [];
    }
  }

  /// جلب المباريات القادمة من TheSportDB (بديل)
  Future<List<Map<String, dynamic>>> _getNextMatchesFromTheSportDB() async {
    try {
      final response = await http.get(
        Uri.parse('$theSportsDbUrl/eventsnext.php?id=$ahlyTeamId'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null) {
          return List<Map<String, dynamic>>.from(data['results']);
        }
      }
      return [];
    } catch (e) {
      print('خطأ في TheSportDB: $e');
      return [];
    }
  }

  /// جلب آخر المباريات (النتائج السابقة) من Football API
  Future<List<Map<String, dynamic>>> getLastMatches() async {
    try {
      // محاولة جلب من Football API أولاً
      final footballMatches = await _getLastMatchesFromFootballApi();
      if (footballMatches.isNotEmpty) {
        return footballMatches;
      }
      
      // إذا فشل، استخدم TheSportDB
      return await _getLastMatchesFromTheSportDB();
    } catch (e) {
      print('خطأ في جلب المباريات السابقة: $e');
      return [];
    }
  }

  /// جلب آخر المباريات من Football API
  Future<List<Map<String, dynamic>>> _getLastMatchesFromFootballApi() async {
    try {
      final response = await http.get(
        Uri.parse('$footballApiUrl/teams/$ahlyTeamIdFootballApi/matches?status=FINISHED'),
        headers: {'X-Auth-Token': footballApiKey},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['matches'] != null) {
          return List<Map<String, dynamic>>.from(
            (data['matches'] as List).take(10).map((match) => {
              'id': match['id'],
              'utcDate': match['utcDate'],
              'status': match['status'],
              'homeTeam': match['homeTeam']['name'],
              'awayTeam': match['awayTeam']['name'],
              'homeTeamId': match['homeTeam']['id'],
              'awayTeamId': match['awayTeam']['id'],
              'score': {
                'fullTime': match['score']['fullTime'],
                'halfTime': match['score']['halfTime'],
              },
              'competition': match['competition']['name'],
            })
          );
        }
      }
      return [];
    } catch (e) {
      print('خطأ في Football API: $e');
      return [];
    }
  }

  /// جلب آخر المباريات من TheSportDB (بديل)
  Future<List<Map<String, dynamic>>> _getLastMatchesFromTheSportDB() async {
    try {
      final response = await http.get(
        Uri.parse('$theSportsDbUrl/eventslast.php?id=$ahlyTeamId'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null) {
          return List<Map<String, dynamic>>.from(data['results']);
        }
      }
      return [];
    } catch (e) {
      print('خطأ في TheSportDB: $e');
      return [];
    }
  }

  /// جلب تفاصيل مباراة محددة من Football API
  Future<Map<String, dynamic>?> getMatchDetails(String eventId) async {
    try {
      // محاولة جلب من Football API أولاً
      final footballMatch = await _getMatchDetailsFromFootballApi(eventId);
      if (footballMatch != null) {
        return footballMatch;
      }
      
      // إذا فشل، استخدم TheSportDB
      return await _getMatchDetailsFromTheSportDB(eventId);
    } catch (e) {
      print('خطأ في جلب تفاصيل المباراة: $e');
      return null;
    }
  }

  /// جلب تفاصيل مباراة من Football API
  Future<Map<String, dynamic>?> _getMatchDetailsFromFootballApi(String matchId) async {
    try {
      final response = await http.get(
        Uri.parse('$footballApiUrl/matches/$matchId'),
        headers: {'X-Auth-Token': footballApiKey},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'id': data['id'],
          'utcDate': data['utcDate'],
          'status': data['status'],
          'homeTeam': data['homeTeam']['name'],
          'awayTeam': data['awayTeam']['name'],
          'score': data['score'],
          'competition': data['competition']['name'],
          'referees': data['referees'],
          'season': data['season'],
        };
      }
      return null;
    } catch (e) {
      print('خطأ في Football API: $e');
      return null;
    }
  }

  /// جلب تفاصيل مباراة من TheSportDB (بديل)
  Future<Map<String, dynamic>?> _getMatchDetailsFromTheSportDB(String eventId) async {
    try {
      final response = await http.get(
        Uri.parse('$theSportsDbUrl/lookupevent.php?id=$eventId'),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['results'] != null && data['results'].isNotEmpty) {
          return data['results'][0];
        }
      }
      return null;
    } catch (e) {
      print('خطأ في TheSportDB: $e');
      return null;
    }
  }

  /// جلب إحصائيات الفريق من Football API
  Future<Map<String, dynamic>?> getTeamStats() async {
    try {
      final response = await http.get(
        Uri.parse('$footballApiUrl/teams/$ahlyTeamIdFootballApi'),
        headers: {'X-Auth-Token': footballApiKey},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return {
          'name': data['name'],
          'founded': data['founded'],
          'venue': data['venue'],
          'website': data['website'],
          'email': data['email'],
          'phone': data['phone'],
          'crest': data['crestUrl'],
          'address': data['address'],
          'area': data['area']['name'],
        };
      }
      return null;
    } catch (e) {
      print('خطأ في جلب إحصائيات الفريق: $e');
      return null;
    }
  }

  /// جلب لاعبي الفريق من Football API
  Future<List<Map<String, dynamic>>> getTeamPlayers() async {
    try {
      final response = await http.get(
        Uri.parse('$footballApiUrl/teams/$ahlyTeamIdFootballApi'),
        headers: {'X-Auth-Token': footballApiKey},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['squad'] != null) {
          return List<Map<String, dynamic>>.from(
            (data['squad'] as List).map((player) => {
              'id': player['id'],
              'name': player['name'],
              'position': player['position'],
              'dateOfBirth': player['dateOfBirth'],
              'nationality': player['nationality'],
              'shirtNumber': player['shirtNumber'],
              'contractUntil': player['contractUntil'],
            })
          );
        }
      }
      return [];
    } catch (e) {
      print('خطأ في جلب لاعبي الفريق: $e');
      return [];
    }
  }

  /// صيغة تاريخ ووقت المباراة
  String formatMatchDateTime(String? date, String? time) {
    if (date == null || date.isEmpty) return 'تاريخ غير محدد';
    
    try {
      final dateTime = DateTime.parse('$date ${time ?? '00:00:00'}');
      return '${dateTime.day}/${dateTime.month}/${dateTime.year} - ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return date;
    }
  }

  /// الحصول على حالة المباراة
  String getMatchStatus(String? status) {
    switch (status?.toUpperCase()) {
      case 'FINISHED':
      case 'MATCH FINISHED':
        return 'انتهت المباراة';
      case 'SCHEDULED':
      case 'MATCH SCHEDULED':
        return 'مجدولة';
      case 'IN_PLAY':
      case 'IN PLAY':
        return 'جارية';
      case 'POSTPONED':
        return 'مؤجلة';
      case 'CANCELLED':
        return 'ملغاة';
      case 'SUSPENDED':
        return 'معلقة';
      default:
        return status ?? 'حالة غير معروفة';
    }
  }

  /// تحويل وقت ISO إلى صيغة عربية
  String formatISODateTime(String? isoDate) {
    if (isoDate == null || isoDate.isEmpty) return 'تاريخ غير محدد';
    
    try {
      final dateTime = DateTime.parse(isoDate).toLocal();
      final months = [
        'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
        'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
      ];
      final days = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      
      return '${days[dateTime.weekday % 7]} ${dateTime.day} ${months[dateTime.month - 1]} ${dateTime.year} - ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return isoDate;
    }
  }
}

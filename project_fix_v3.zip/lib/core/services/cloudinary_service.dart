import 'package:cloudinary_public/cloudinary_public.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class CloudinaryService {
  // Cloudinary Configuration
  static const String cloudName = 'dubc6k1iy'; // Cloud Name الخاص بك
  static const String apiKey = '497232166977864';
  static const String uploadPreset = 'ahly_fans_preset'; // أنشئ upload preset في Cloudinary
  
  final CloudinaryPublic _cloudinary = CloudinaryPublic(
    cloudName,
    uploadPreset,
    cache: false,
  );

  final FirebaseDatabase _firebaseDatabase = FirebaseDatabase.instance;
  final ImagePicker _imagePicker = ImagePicker();

  /// رفع فيديو إلى Cloudinary وحفظ البيانات في Firebase
  Future<Map<String, dynamic>?> uploadVideo({
    required File videoFile,
    required String userId,
    required String caption,
    required String userName,
    String? folder = 'reels',
  }) async {
    try {
      print('جاري رفع الفيديو...');
      
      // رفع الفيديو إلى Cloudinary
      final response = await _cloudinary.uploadResource(
        CloudinaryFile.fromFile(
          videoFile.path,
          resourceType: CloudinaryResourceType.video,
          folder: folder,
        ),
      );

      if (response.isSuccessful) {
        final videoUrl = response.secureUrl;
        final publicId = response.publicId;

        print('تم رفع الفيديو بنجاح: $videoUrl');

        // حفظ البيانات في Firebase Realtime Database
        final reelId = DateTime.now().millisecondsSinceEpoch.toString();
        await _firebaseDatabase.ref('Reels/$reelId').set({
          'videoUrl': videoUrl,
          'publicId': publicId,
          'userId': userId,
          'userName': userName,
          'caption': caption,
          'likes': 0,
          'comments': 0,
          'shares': 0,
          'views': 0,
          'createdAt': DateTime.now().toIso8601String(),
          'userProfilePic': '',
          'thumbnail': _generateThumbnailUrl(videoUrl),
          'duration': 0, // سيتم تحديثه لاحقاً
          'status': 'published',
        });

        print('تم حفظ بيانات الريل في Firebase');

        return {
          'success': true,
          'videoUrl': videoUrl,
          'publicId': publicId,
          'reelId': reelId,
          'message': 'تم رفع الفيديو بنجاح',
        };
      } else {
        print('فشل رفع الفيديو: ${response.error}');
        return {'success': false, 'error': 'فشل رفع الفيديو: ${response.error}'};
      }
    } catch (e) {
      print('خطأ في رفع الفيديو: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// رفع صورة إلى Cloudinary وحفظ البيانات في Firebase
  Future<Map<String, dynamic>?> uploadImage({
    required File imageFile,
    required String userId,
    String? folder = 'assets',
  }) async {
    try {
      print('جاري رفع الصورة...');
      
      final response = await _cloudinary.uploadResource(
        CloudinaryFile.fromFile(
          imageFile.path,
          resourceType: CloudinaryResourceType.image,
          folder: folder,
        ),
      );

      if (response.isSuccessful) {
        final imageUrl = response.secureUrl;
        final publicId = response.publicId;

        print('تم رفع الصورة بنجاح: $imageUrl');

        return {
          'success': true,
          'imageUrl': imageUrl,
          'publicId': publicId,
          'message': 'تم رفع الصورة بنجاح',
        };
      } else {
        print('فشل رفع الصورة: ${response.error}');
        return {'success': false, 'error': 'فشل رفع الصورة: ${response.error}'};
      }
    } catch (e) {
      print('خطأ في رفع الصورة: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// اختيار فيديو من المعرض ورفعه
  Future<Map<String, dynamic>?> pickAndUploadVideo({
    required String userId,
    required String caption,
    required String userName,
  }) async {
    try {
      final pickedFile = await _imagePicker.pickVideo(source: ImageSource.gallery);
      
      if (pickedFile != null) {
        final file = File(pickedFile.path);
        return await uploadVideo(
          videoFile: file,
          userId: userId,
          caption: caption,
          userName: userName,
        );
      }
      return {'success': false, 'error': 'لم يتم اختيار فيديو'};
    } catch (e) {
      print('خطأ في اختيار الفيديو: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// تسجيل فيديو من الكاميرا ورفعه
  Future<Map<String, dynamic>?> recordAndUploadVideo({
    required String userId,
    required String caption,
    required String userName,
  }) async {
    try {
      final pickedFile = await _imagePicker.pickVideo(source: ImageSource.camera);
      
      if (pickedFile != null) {
        final file = File(pickedFile.path);
        return await uploadVideo(
          videoFile: file,
          userId: userId,
          caption: caption,
          userName: userName,
        );
      }
      return {'success': false, 'error': 'لم يتم تسجيل فيديو'};
    } catch (e) {
      print('خطأ في تسجيل الفيديو: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// اختيار صورة من المعرض ورفعها
  Future<Map<String, dynamic>?> pickAndUploadImage({
    required String userId,
  }) async {
    try {
      final pickedFile = await _imagePicker.pickImage(source: ImageSource.gallery);
      
      if (pickedFile != null) {
        final file = File(pickedFile.path);
        return await uploadImage(
          imageFile: file,
          userId: userId,
        );
      }
      return {'success': false, 'error': 'لم يتم اختيار صورة'};
    } catch (e) {
      print('خطأ في اختيار الصورة: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// التقاط صورة من الكاميرا ورفعها
  Future<Map<String, dynamic>?> captureAndUploadImage({
    required String userId,
  }) async {
    try {
      final pickedFile = await _imagePicker.pickImage(source: ImageSource.camera);
      
      if (pickedFile != null) {
        final file = File(pickedFile.path);
        return await uploadImage(
          imageFile: file,
          userId: userId,
        );
      }
      return {'success': false, 'error': 'لم يتم التقاط صورة'};
    } catch (e) {
      print('خطأ في التقاط الصورة: $e');
      return {'success': false, 'error': 'خطأ: $e'};
    }
  }

  /// حذف ملف من Cloudinary
  Future<bool> deleteResource(String publicId) async {
    try {
      // يتطلب API Secret للحذف - يجب تنفيذه من Backend
      print('حذف الملف: $publicId');
      return true;
    } catch (e) {
      print('خطأ في حذف الملف: $e');
      return false;
    }
  }

  /// جلب جميع الريلز من Firebase
  Stream<List<Map<String, dynamic>>> getReels() {
    return _firebaseDatabase.ref('Reels').onValue.map((event) {
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        final reels = data.values.map((reel) {
          return Map<String, dynamic>.from(reel as Map);
        }).toList();
        
        // ترتيب حسب التاريخ (الأحدث أولاً)
        reels.sort((a, b) {
          final dateA = DateTime.tryParse(a['createdAt'] ?? '') ?? DateTime.now();
          final dateB = DateTime.tryParse(b['createdAt'] ?? '') ?? DateTime.now();
          return dateB.compareTo(dateA);
        });
        
        return reels;
      }
      return [];
    });
  }

  /// جلب ريلز المستخدم
  Stream<List<Map<String, dynamic>>> getUserReels(String userId) {
    return _firebaseDatabase
        .ref('Reels')
        .orderByChild('userId')
        .equalTo(userId)
        .onValue
        .map((event) {
      if (event.snapshot.value != null) {
        final data = Map<String, dynamic>.from(event.snapshot.value as Map);
        return data.values.map((reel) {
          return Map<String, dynamic>.from(reel as Map);
        }).toList();
      }
      return [];
    });
  }

  /// إضافة إعجاب للريل
  Future<bool> likeReel(String reelId) async {
    try {
      final ref = _firebaseDatabase.ref('Reels/$reelId');
      final snapshot = await ref.child('likes').get();
      final currentLikes = (snapshot.value as int?) ?? 0;
      
      await ref.child('likes').set(currentLikes + 1);
      return true;
    } catch (e) {
      print('خطأ في إضافة إعجاب: $e');
      return false;
    }
  }

  /// إزالة إعجاب من الريل
  Future<bool> unlikeReel(String reelId) async {
    try {
      final ref = _firebaseDatabase.ref('Reels/$reelId');
      final snapshot = await ref.child('likes').get();
      final currentLikes = (snapshot.value as int?) ?? 0;
      
      if (currentLikes > 0) {
        await ref.child('likes').set(currentLikes - 1);
      }
      return true;
    } catch (e) {
      print('خطأ في إزالة الإعجاب: $e');
      return false;
    }
  }

  /// إضافة تعليق على الريل
  Future<bool> addComment(String reelId, String userId, String comment) async {
    try {
      final commentId = DateTime.now().millisecondsSinceEpoch.toString();
      await _firebaseDatabase.ref('Reels/$reelId/comments/$commentId').set({
        'userId': userId,
        'comment': comment,
        'createdAt': DateTime.now().toIso8601String(),
        'likes': 0,
      });
      
      // تحديث عدد التعليقات
      final ref = _firebaseDatabase.ref('Reels/$reelId');
      final snapshot = await ref.child('comments').get();
      final currentComments = (snapshot.value as int?) ?? 0;
      await ref.child('comments').set(currentComments + 1);
      
      return true;
    } catch (e) {
      print('خطأ في إضافة تعليق: $e');
      return false;
    }
  }

  /// مشاركة الريل
  Future<bool> shareReel(String reelId) async {
    try {
      final ref = _firebaseDatabase.ref('Reels/$reelId');
      final snapshot = await ref.child('shares').get();
      final currentShares = (snapshot.value as int?) ?? 0;
      
      await ref.child('shares').set(currentShares + 1);
      return true;
    } catch (e) {
      print('خطأ في مشاركة الريل: $e');
      return false;
    }
  }

  /// تحديث عدد المشاهدات
  Future<bool> incrementViews(String reelId) async {
    try {
      final ref = _firebaseDatabase.ref('Reels/$reelId');
      final snapshot = await ref.child('views').get();
      final currentViews = (snapshot.value as int?) ?? 0;
      
      await ref.child('views').set(currentViews + 1);
      return true;
    } catch (e) {
      print('خطأ في تحديث المشاهدات: $e');
      return false;
    }
  }

  /// حذف الريل
  Future<bool> deleteReel(String reelId, String publicId) async {
    try {
      // حذف من Firebase
      await _firebaseDatabase.ref('Reels/$reelId').remove();
      
      // حذف من Cloudinary (يتطلب Backend)
      await deleteResource(publicId);
      
      return true;
    } catch (e) {
      print('خطأ في حذف الريل: $e');
      return false;
    }
  }

  /// البحث عن الريلز
  Future<List<Map<String, dynamic>>> searchReels(String query) async {
    try {
      final snapshot = await _firebaseDatabase.ref('Reels').get();
      
      if (snapshot.value != null) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        final reels = data.values
            .map((reel) => Map<String, dynamic>.from(reel as Map))
            .where((reel) {
              final caption = (reel['caption'] ?? '').toString().toLowerCase();
              final userName = (reel['userName'] ?? '').toString().toLowerCase();
              return caption.contains(query.toLowerCase()) || 
                     userName.contains(query.toLowerCase());
            })
            .toList();
        
        return reels;
      }
      return [];
    } catch (e) {
      print('خطأ في البحث: $e');
      return [];
    }
  }

  /// الحصول على الريلز الشهيرة (الأكثر إعجاباً)
  Future<List<Map<String, dynamic>>> getTrendingReels() async {
    try {
      final snapshot = await _firebaseDatabase.ref('Reels').get();
      
      if (snapshot.value != null) {
        final data = Map<String, dynamic>.from(snapshot.value as Map);
        final reels = data.values
            .map((reel) => Map<String, dynamic>.from(reel as Map))
            .toList();
        
        // ترتيب حسب الإعجابات
        reels.sort((a, b) => (b['likes'] ?? 0).compareTo(a['likes'] ?? 0));
        
        return reels.take(10).toList();
      }
      return [];
    } catch (e) {
      print('خطأ في جلب الريلز الشهيرة: $e');
      return [];
    }
  }

  /// إنشاء رابط محسّن للصورة
  String getOptimizedImageUrl(String imageUrl, {int width = 400, int height = 300}) {
    if (!imageUrl.contains('cloudinary.com')) {
      return imageUrl;
    }
    
    final parts = imageUrl.split('/upload/');
    if (parts.length == 2) {
      final transformations = 'w_$width,h_$height,c_fill,q_auto,f_auto';
      return '${parts[0]}/upload/$transformations/${parts[1]}';
    }
    
    return imageUrl;
  }

  /// إنشاء صورة مصغرة للفيديو
  String _generateThumbnailUrl(String videoUrl) {
    if (!videoUrl.contains('cloudinary.com')) {
      return videoUrl;
    }
    
    final parts = videoUrl.split('/upload/');
    if (parts.length == 2) {
      final transformations = 'w_300,h_300,c_thumb,q_auto,f_auto';
      return '${parts[0]}/upload/$transformations/${parts[1]}';
    }
    
    return videoUrl;
  }

  /// الحصول على إحصائيات الريل
  Future<Map<String, dynamic>?> getReelStats(String reelId) async {
    try {
      final snapshot = await _firebaseDatabase.ref('Reels/$reelId').get();
      
      if (snapshot.exists && snapshot.value is Map) {
        return Map<String, dynamic>.from(snapshot.value as Map);
      }
      return null;
    } catch (e) {
      print('خطأ في جلب إحصائيات الريل: $e');
      return null;
    }
  }
}

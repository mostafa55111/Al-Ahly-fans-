/// استثناءات التطبيق المخصصة
/// 
/// تحتوي هذه الملف على جميع أنواع الاستثناءات المخصصة للتطبيق
/// مما يسمح بمعالجة الأخطاء بشكل أكثر دقة وتفصيلاً

/// الفئة الأساسية لجميع استثناءات التطبيق
abstract class AppException implements Exception {
  final String message;
  final String? code;
  final dynamic originalException;
  final StackTrace? stackTrace;

  AppException({
    required this.message,
    this.code,
    this.originalException,
    this.stackTrace,
  });

  @override
  String toString() => 'AppException: $message (Code: $code)';
}

// ===== Network Exceptions =====

/// استثناء الشبكة العام
class NetworkException extends AppException {
  NetworkException({
    required String message,
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'NETWORK_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء انقطاع الاتصال
class NoInternetException extends NetworkException {
  NoInternetException({
    String message = 'لا يوجد اتصال بالإنترنت',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'NO_INTERNET',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء انتهاء مهلة الاتصال
class TimeoutException extends NetworkException {
  TimeoutException({
    String message = 'انتهت مهلة الاتصال',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'TIMEOUT',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء فشل الاتصال
class ConnectionFailedException extends NetworkException {
  ConnectionFailedException({
    String message = 'فشل الاتصال',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'CONNECTION_FAILED',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Server Exceptions =====

/// استثناء الخادم العام
class ServerException extends AppException {
  final int? statusCode;

  ServerException({
    required String message,
    this.statusCode,
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'SERVER_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء خطأ 400
class BadRequestException extends ServerException {
  BadRequestException({
    String message = 'طلب غير صحيح',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    statusCode: 400,
    code: 'BAD_REQUEST',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء خطأ 401 (غير مصرح)
class UnauthorizedException extends ServerException {
  UnauthorizedException({
    String message = 'غير مصرح - يرجى تسجيل الدخول',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    statusCode: 401,
    code: 'UNAUTHORIZED',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء خطأ 403 (محظور)
class ForbiddenException extends ServerException {
  ForbiddenException({
    String message = 'محظور - ليس لديك صلاحيات كافية',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    statusCode: 403,
    code: 'FORBIDDEN',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء خطأ 404 (غير موجود)
class NotFoundException extends ServerException {
  NotFoundException({
    String message = 'المورد غير موجود',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    statusCode: 404,
    code: 'NOT_FOUND',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء خطأ 500 (خطأ في الخادم)
class InternalServerException extends ServerException {
  InternalServerException({
    String message = 'خطأ في الخادم',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    statusCode: 500,
    code: 'INTERNAL_SERVER_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Firebase Exceptions =====

/// استثناء Firebase العام
class FirebaseException extends AppException {
  FirebaseException({
    required String message,
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'FIREBASE_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء فشل المصادقة
class AuthenticationException extends FirebaseException {
  AuthenticationException({
    String message = 'فشل المصادقة',
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'AUTH_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء فشل قاعدة البيانات
class DatabaseException extends FirebaseException {
  DatabaseException({
    String message = 'خطأ في قاعدة البيانات',
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'DATABASE_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء فشل التخزين
class StorageException extends FirebaseException {
  StorageException({
    String message = 'خطأ في التخزين',
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'STORAGE_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Data Exceptions =====

/// استثناء البيانات العام
class DataException extends AppException {
  DataException({
    required String message,
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'DATA_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء البيانات الفارغة
class EmptyDataException extends DataException {
  EmptyDataException({
    String message = 'لا توجد بيانات',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'EMPTY_DATA',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء فشل تحويل البيانات
class DataConversionException extends DataException {
  DataConversionException({
    String message = 'فشل تحويل البيانات',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'DATA_CONVERSION_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

/// استثناء البيانات غير الصحيحة
class InvalidDataException extends DataException {
  InvalidDataException({
    String message = 'بيانات غير صحيحة',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'INVALID_DATA',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Validation Exceptions =====

/// استثناء التحقق العام
class ValidationException extends AppException {
  final List<String> errors;

  ValidationException({
    required String message,
    required this.errors,
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'VALIDATION_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Cache Exceptions =====

/// استثناء الكاش العام
class CacheException extends AppException {
  CacheException({
    String message = 'خطأ في الكاش',
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'CACHE_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Permission Exceptions =====

/// استثناء الصلاحيات
class PermissionException extends AppException {
  PermissionException({
    String message = 'لا توجد صلاحيات كافية',
    String? code,
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: code ?? 'PERMISSION_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

// ===== Unknown Exception =====

/// استثناء غير معروف
class UnknownException extends AppException {
  UnknownException({
    String message = 'حدث خطأ غير متوقع',
    dynamic originalException,
    StackTrace? stackTrace,
  }) : super(
    message: message,
    code: 'UNKNOWN_ERROR',
    originalException: originalException,
    stackTrace: stackTrace,
  );
}

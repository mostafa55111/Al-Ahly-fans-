import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
// import 'firebase_options.dart'; // تمت إزالتها لتجنب التعارض مع الملف الخارجي

/// Firebase Configuration Class
/// يتعامل مع تهيئة Firebase وإعدادات الاتصال
class FirebaseConfig {
  static late FirebaseApp _firebaseApp;
  static late FirebaseDatabase _database;
  static late FirebaseAuth _auth;
  static late FirebaseStorage _storage;

  /// تهيئة Firebase
  static Future<void> initialize() async {
    try {
      _firebaseApp = await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );

      // تهيئة Realtime Database
      _database = FirebaseDatabase.instance;
      _database.setPersistenceEnabled(true);
      _database.setLoggingEnabled(true);

      // تهيئة Authentication
      _auth = FirebaseAuth.instance;

      // تهيئة Storage
      _storage = FirebaseStorage.instance;

      print('✅ Firebase initialized successfully');
    } catch (e) {
      print('❌ Firebase initialization error: $e');
      rethrow;
    }
  }

  /// الحصول على Database Instance
  static FirebaseDatabase getDatabase() {
    return _database;
  }

  /// الحصول على Auth Instance
  static FirebaseAuth getAuth() {
    return _auth;
  }

  /// الحصول على Storage Reference
  static FirebaseStorage getStorage() {
    return _storage;
  }

  /// الحصول على Current User ID
  static String? getCurrentUserId() {
    return _auth.currentUser?.uid;
  }

  /// التحقق من تسجيل الدخول
  static bool isLoggedIn() {
    return _auth.currentUser != null;
  }

  /// تسجيل الخروج
  static Future<void> logout() async {
    await _auth.signOut();
  }
}

/// Firebase Options
class DefaultFirebaseOptions {
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'YOUR_WEB_API_KEY',
    appId: 'YOUR_WEB_APP_ID',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    projectId: 'YOUR_PROJECT_ID',
    authDomain: 'YOUR_AUTH_DOMAIN',
    databaseURL: 'YOUR_DATABASE_URL',
    storageBucket: 'YOUR_STORAGE_BUCKET',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'YOUR_ANDROID_API_KEY',
    appId: 'YOUR_ANDROID_APP_ID',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    projectId: 'YOUR_PROJECT_ID',
    databaseURL: 'YOUR_DATABASE_URL',
    storageBucket: 'YOUR_STORAGE_BUCKET',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'YOUR_IOS_API_KEY',
    appId: 'YOUR_IOS_APP_ID',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    projectId: 'YOUR_PROJECT_ID',
    databaseURL: 'YOUR_DATABASE_URL',
    storageBucket: 'YOUR_STORAGE_BUCKET',
  );

  static FirebaseOptions get currentPlatform {
    // تحديد المنصة الحالية
    if (identical(0, 0.0)) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }
}

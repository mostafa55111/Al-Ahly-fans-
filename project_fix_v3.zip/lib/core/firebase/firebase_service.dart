import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'firebase_config.dart';

/// Firebase Service
/// يوفر واجهة موحدة للتعامل مع Firebase
class FirebaseService {
  static final FirebaseService _instance = FirebaseService._internal();

  factory FirebaseService() {
    return _instance;
  }

  FirebaseService._internal();

  // Database References
  late DatabaseReference _postsRef;
  late DatabaseReference _usersRef;
  late DatabaseReference _followsRef;
  late DatabaseReference _achievementsRef;
  late DatabaseReference _leaderboardRef;
  late DatabaseReference _matchesRef;
  late DatabaseReference _storiesRef;
  late DatabaseReference _commentsRef;
  late DatabaseReference _notificationsRef;

  /// تهيئة الـ References
  void initialize() {
    final db = FirebaseConfig.getDatabase();

    _postsRef = db.ref().child('posts');
    _usersRef = db.ref().child('users');
    _followsRef = db.ref().child('follows');
    _achievementsRef = db.ref().child('achievements');
    _leaderboardRef = db.ref().child('leaderboard');
    _matchesRef = db.ref().child('matches');
    _storiesRef = db.ref().child('stories');
    _commentsRef = db.ref().child('comments');
    _notificationsRef = db.ref().child('notifications');

    print('✅ Firebase Service initialized');
  }

  // ==================== Posts ====================

  /// إنشاء منشور جديد
  Future<String> createPost(Map<String, dynamic> postData) async {
    try {
      final newPostRef = _postsRef.push();
      await newPostRef.set({
        ...postData,
        'createdAt': DateTime.now().toIso8601String(),
        'updatedAt': DateTime.now().toIso8601String(),
      });
      return newPostRef.key!;
    } catch (e) {
      throw Exception('فشل إنشاء المنشور: $e');
    }
  }

  /// الحصول على جميع المنشورات
  Future<List<Map<String, dynamic>>> getAllPosts() async {
    try {
      final snapshot = await _postsRef.get();
      if (!snapshot.exists) return [];

      final posts = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        posts.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return posts;
    } catch (e) {
      throw Exception('فشل جلب المنشورات: $e');
    }
  }

  /// تحديث منشور
  Future<void> updatePost(String postId, Map<String, dynamic> updates) async {
    try {
      await _postsRef.child(postId).update({
        ...updates,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('فشل تحديث المنشور: $e');
    }
  }

  /// حذف منشور
  Future<void> deletePost(String postId) async {
    try {
      await _postsRef.child(postId).remove();
    } catch (e) {
      throw Exception('فشل حذف المنشور: $e');
    }
  }

  /// الإعجاب بمنشور
  Future<void> likePost(String postId, String userId) async {
    try {
      await _postsRef.child(postId).child('likes').child(userId).set(true);
      
      // زيادة عدد الإعجابات
      final snapshot = await _postsRef.child(postId).child('likesCount').get();
      final currentLikes = (snapshot.value as int?) ?? 0;
      await _postsRef.child(postId).update({'likesCount': currentLikes + 1});
    } catch (e) {
      throw Exception('فشل الإعجاب: $e');
    }
  }

  /// إلغاء الإعجاب
  Future<void> unlikePost(String postId, String userId) async {
    try {
      await _postsRef.child(postId).child('likes').child(userId).remove();
      
      // تقليل عدد الإعجابات
      final snapshot = await _postsRef.child(postId).child('likesCount').get();
      final currentLikes = (snapshot.value as int?) ?? 0;
      if (currentLikes > 0) {
        await _postsRef.child(postId).update({'likesCount': currentLikes - 1});
      }
    } catch (e) {
      throw Exception('فشل إلغاء الإعجاب: $e');
    }
  }

  // ==================== Users ====================

  /// إنشاء ملف تعريفي للمستخدم
  Future<void> createUserProfile(String userId, Map<String, dynamic> userData) async {
    try {
      await _usersRef.child(userId).set({
        ...userData,
        'createdAt': DateTime.now().toIso8601String(),
        'followersCount': 0,
        'followingCount': 0,
        'postsCount': 0,
      });
    } catch (e) {
      throw Exception('فشل إنشاء الملف التعريفي: $e');
    }
  }

  /// الحصول على بيانات المستخدم
  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final snapshot = await _usersRef.child(userId).get();
      if (!snapshot.exists) return null;

      return Map<String, dynamic>.from(snapshot.value as Map<dynamic, dynamic>);
    } catch (e) {
      throw Exception('فشل جلب بيانات المستخدم: $e');
    }
  }

  /// تحديث بيانات المستخدم
  Future<void> updateUserProfile(String userId, Map<String, dynamic> updates) async {
    try {
      await _usersRef.child(userId).update(updates);
    } catch (e) {
      throw Exception('فشل تحديث الملف التعريفي: $e');
    }
  }

  // ==================== Follows ====================

  /// متابعة مستخدم
  Future<void> followUser(String currentUserId, String targetUserId) async {
    try {
      // إضافة المتابعة
      await _followsRef.child(currentUserId).child(targetUserId).set(true);

      // زيادة عدد المتابعين للمستخدم المستهدف
      final snapshot = await _usersRef.child(targetUserId).child('followersCount').get();
      final currentFollowers = (snapshot.value as int?) ?? 0;
      await _usersRef.child(targetUserId).update({'followersCount': currentFollowers + 1});

      // زيادة عدد المتابعة للمستخدم الحالي
      final snapshot2 = await _usersRef.child(currentUserId).child('followingCount').get();
      final currentFollowing = (snapshot2.value as int?) ?? 0;
      await _usersRef.child(currentUserId).update({'followingCount': currentFollowing + 1});
    } catch (e) {
      throw Exception('فشل المتابعة: $e');
    }
  }

  /// إلغاء المتابعة
  Future<void> unfollowUser(String currentUserId, String targetUserId) async {
    try {
      // إزالة المتابعة
      await _followsRef.child(currentUserId).child(targetUserId).remove();

      // تقليل عدد المتابعين للمستخدم المستهدف
      final snapshot = await _usersRef.child(targetUserId).child('followersCount').get();
      final currentFollowers = (snapshot.value as int?) ?? 0;
      if (currentFollowers > 0) {
        await _usersRef.child(targetUserId).update({'followersCount': currentFollowers - 1});
      }

      // تقليل عدد المتابعة للمستخدم الحالي
      final snapshot2 = await _usersRef.child(currentUserId).child('followingCount').get();
      final currentFollowing = (snapshot2.value as int?) ?? 0;
      if (currentFollowing > 0) {
        await _usersRef.child(currentUserId).update({'followingCount': currentFollowing - 1});
      }
    } catch (e) {
      throw Exception('فشل إلغاء المتابعة: $e');
    }
  }

  // ==================== Achievements ====================

  /// إضافة إنجاز للمستخدم
  Future<void> addAchievement(String userId, Map<String, dynamic> achievement) async {
    try {
      final achievementRef = _achievementsRef.child(userId).push();
      await achievementRef.set({
        ...achievement,
        'unlockedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('فشل إضافة الإنجاز: $e');
    }
  }

  /// الحصول على إنجازات المستخدم
  Future<List<Map<String, dynamic>>> getUserAchievements(String userId) async {
    try {
      final snapshot = await _achievementsRef.child(userId).get();
      if (!snapshot.exists) return [];

      final achievements = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        achievements.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return achievements;
    } catch (e) {
      throw Exception('فشل جلب الإنجازات: $e');
    }
  }

  // ==================== Leaderboard ====================

  /// تحديث ترتيب المستخدم
  Future<void> updateLeaderboardRank(String userId, Map<String, dynamic> rankData) async {
    try {
      await _leaderboardRef.child(userId).set({
        ...rankData,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('فشل تحديث الترتيب: $e');
    }
  }

  /// الحصول على الترتيبات
  Future<List<Map<String, dynamic>>> getLeaderboard({int limit = 100}) async {
    try {
      final snapshot = await _leaderboardRef.limitToFirst(limit).get();
      if (!snapshot.exists) return [];

      final leaderboard = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        leaderboard.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return leaderboard;
    } catch (e) {
      throw Exception('فشل جلب الترتيبات: $e');
    }
  }

  // ==================== Matches ====================

  /// إنشاء مباراة جديدة
  Future<String> createMatch(Map<String, dynamic> matchData) async {
    try {
      final newMatchRef = _matchesRef.push();
      await newMatchRef.set({
        ...matchData,
        'createdAt': DateTime.now().toIso8601String(),
      });
      return newMatchRef.key!;
    } catch (e) {
      throw Exception('فشل إنشاء المباراة: $e');
    }
  }

  /// تحديث حالة المباراة
  Future<void> updateMatchStatus(String matchId, String status) async {
    try {
      await _matchesRef.child(matchId).update({
        'status': status,
        'updatedAt': DateTime.now().toIso8601String(),
      });
    } catch (e) {
      throw Exception('فشل تحديث حالة المباراة: $e');
    }
  }

  /// الحصول على المباريات المباشرة
  Future<List<Map<String, dynamic>>> getLiveMatches() async {
    try {
      final snapshot = await _matchesRef.orderByChild('status').equalTo('live').get();
      if (!snapshot.exists) return [];

      final matches = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        matches.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return matches;
    } catch (e) {
      throw Exception('فشل جلب المباريات المباشرة: $e');
    }
  }

  // ==================== Stories ====================

  /// إنشاء قصة جديدة
  Future<String> createStory(String userId, Map<String, dynamic> storyData) async {
    try {
      final newStoryRef = _storiesRef.push();
      await newStoryRef.set({
        ...storyData,
        'userId': userId,
        'createdAt': DateTime.now().toIso8601String(),
        'expiresAt': DateTime.now().add(const Duration(hours: 24)).toIso8601String(),
      });
      return newStoryRef.key!;
    } catch (e) {
      throw Exception('فشل إنشاء القصة: $e');
    }
  }

  /// الحصول على قصص المستخدم
  Future<List<Map<String, dynamic>>> getUserStories(String userId) async {
    try {
      final snapshot = await _storiesRef.orderByChild('userId').equalTo(userId).get();
      if (!snapshot.exists) return [];

      final stories = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        stories.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return stories;
    } catch (e) {
      throw Exception('فشل جلب القصص: $e');
    }
  }

  // ==================== Comments ====================

  /// إضافة تعليق
  Future<String> addComment(String postId, Map<String, dynamic> commentData) async {
    try {
      final newCommentRef = _commentsRef.child(postId).push();
      await newCommentRef.set({
        ...commentData,
        'createdAt': DateTime.now().toIso8601String(),
      });
      return newCommentRef.key!;
    } catch (e) {
      throw Exception('فشل إضافة التعليق: $e');
    }
  }

  /// الحصول على تعليقات المنشور
  Future<List<Map<String, dynamic>>> getPostComments(String postId) async {
    try {
      final snapshot = await _commentsRef.child(postId).get();
      if (!snapshot.exists) return [];

      final comments = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        comments.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return comments;
    } catch (e) {
      throw Exception('فشل جلب التعليقات: $e');
    }
  }

  // ==================== Notifications ====================

  /// إرسال إشعار
  Future<void> sendNotification(String userId, Map<String, dynamic> notificationData) async {
    try {
      final newNotificationRef = _notificationsRef.child(userId).push();
      await newNotificationRef.set({
        ...notificationData,
        'createdAt': DateTime.now().toIso8601String(),
        'isRead': false,
      });
    } catch (e) {
      throw Exception('فشل إرسال الإشعار: $e');
    }
  }

  /// الحصول على إشعارات المستخدم
  Future<List<Map<String, dynamic>>> getUserNotifications(String userId) async {
    try {
      final snapshot = await _notificationsRef.child(userId).get();
      if (!snapshot.exists) return [];

      final notifications = <Map<String, dynamic>>[];
      final data = snapshot.value as Map<dynamic, dynamic>;

      for (final entry in data.entries) {
        notifications.add(Map<String, dynamic>.from(entry.value as Map<dynamic, dynamic>));
      }

      return notifications;
    } catch (e) {
      throw Exception('فشل جلب الإشعارات: $e');
    }
  }

  // ==================== Upload Files ====================

  /// رفع صورة
  Future<String> uploadImage(String path, String fileName) async {
    try {
      final storage = FirebaseConfig.getStorage();
      final ref = storage.ref('images/$fileName');
      await ref.putFile(File(path));
      return await ref.getDownloadURL();
    } catch (e) {
      throw Exception('فشل رفع الصورة: $e');
    }
  }

  /// رفع فيديو
  Future<String> uploadVideo(String path, String fileName) async {
    try {
      final storage = FirebaseConfig.getStorage();
      final ref = storage.ref('videos/$fileName');
      await ref.putFile(File(path));
      return await ref.getDownloadURL();
    } catch (e) {
      throw Exception('فشل رفع الفيديو: $e');
    }
  }
}

// استيراد File
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'firebase_options.dart';

// Import Theme
import 'package:gomhor_alahly_clean_new/core/theme/app_theme.dart';

// Import Firebase Config
import 'package:gomhor_alahly_clean_new/core/firebase/firebase_config.dart';
import 'package:gomhor_alahly_clean_new/core/firebase/firebase_service.dart';

// Gemini API Configuration
const String GEMINI_API_KEY = 'AIzaSyCNlqhPN6dkOTjF8DfV9IE4wyEzWjrCgjQ';

// Football API Configuration
const String FOOTBALL_API_KEY = '8c16585903c335eb82435488feac3937';

// Cloudinary API Configuration
const String CLOUDINARY_API_KEY = '497232166977864';
const String CLOUDINARY_CLOUD_NAME = 'dubc6k1iy'; // Cloud Name الخاص بك

// Import Screens
import 'package:gomhor_alahly_clean_new/features/profile/presentation/pages/splash_screen.dart';
import 'package:gomhor_alahly_clean_new/features/profile/presentation/pages/login_screen.dart';
import 'package:gomhor_alahly_clean_new/features/profile/presentation/pages/profile_screen.dart';
import 'package:gomhor_alahly_clean_new/features/reels/presentation/pages/reels_screen.dart';
import 'package:gomhor_alahly_clean_new/features/voting_match_center/presentation/pages/match_center_screen.dart';

/// Initialize Gemini API Key
void initializeGeminiAPI() {
  // API Key is stored in the constant above
  // This function can be called to initialize any Gemini-specific settings
  debugPrint('Gemini API initialized successfully');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    
    // تهيئة Firebase Config
    await FirebaseConfig.initialize();
    debugPrint('✅ Firebase Config initialized successfully');
    
    // تهيئة Firebase Service
    FirebaseService().initialize();
    debugPrint('✅ Firebase Service initialized successfully');
    
    initializeGeminiAPI();
    debugPrint('✅ Firebase and Gemini initialized successfully');
  } catch (e) {
    debugPrint('❌ Initialization error: $e');
  }
  
  runApp(const AlAhlySuperApp());
}

class AlAhlySuperApp extends StatelessWidget {
  const AlAhlySuperApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جمهور الأهلي - نادي القرن',
      theme: AppTheme.darkTheme(),
      home: const AuthWrapper(),
    );
  }
}

/// المتحكم الذكي في الدخول والتوجيه
class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  late Stream<User?> _authStateStream;

  @override
  void initState() {
    super.initState();
    _authStateStream = FirebaseAuth.instance.authStateChanges();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: _authStateStream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SplashScreen();
        }

        if (snapshot.hasData && snapshot.data != null) {
          // المستخدم مسجل دخول
          return const MainHomeScreen();
        } else {
          // المستخدم غير مسجل دخول
          return const LoginScreen();
        }
      },
    );
  }
}

/// الشاشة الرئيسية (Home) لإدارة الريلز والبروفايل ومركز المباريات
class MainHomeScreen extends StatefulWidget {
  const MainHomeScreen({super.key});

  @override
  State<MainHomeScreen> createState() => _MainHomeScreenState();
}

class _MainHomeScreenState extends State<MainHomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const ReelsScreen(),           // الريلز
    const MatchCenterScreen(),     // مركز المباريات
    const ProfileScreen(),         // البروفايل
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(
              color: AppColors.mediumGray.withOpacity(0.3),
              width: 1,
            ),
          ),
        ),
        child: BottomNavigationBar(
          currentIndex: _selectedIndex,
          onTap: (index) => setState(() => _selectedIndex = index),
          backgroundColor: AppColors.darkBlack,
          selectedItemColor: AppColors.luminousGold,
          unselectedItemColor: AppColors.mediumGray,
          type: BottomNavigationBarType.fixed,
          elevation: 8,
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.play_circle_outline),
              activeIcon: Icon(Icons.play_circle_fill),
              label: 'الريلز',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.sports_soccer_outlined),
              activeIcon: Icon(Icons.sports_soccer),
              label: 'المباريات',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'حسابي',
            ),
          ],
        ),
      ),
    );
  }
}

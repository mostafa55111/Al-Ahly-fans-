import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:animate_do/animate_do.dart';
import 'dart:ui';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final user = FirebaseAuth.instance.currentUser;
  late DatabaseReference dbRef;

  @override
  void initState() {
    super.initState();
    dbRef = FirebaseDatabase.instance.ref("users/${user?.uid}");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.search, color: Colors.amber, size: 28),
          onPressed: () => _showSearchDialog(context),
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_none_rounded, color: Colors.amber, size: 28),
                onPressed: () => _showNotifications(context),
              ),
              Positioned(
                right: 12,
                top: 12,
                child: Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                  constraints: const BoxConstraints(minWidth: 8, minHeight: 8),
                ),
              )
            ],
          ),
          IconButton(
            icon: const Icon(Icons.menu_rounded, color: Colors.amber, size: 28),
            onPressed: () => _openMenu(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // زخرفة ذهبية في الخلفية
          Positioned.fill(
            child: Opacity(
              opacity: 0.05,
              child: Image.asset('assets/images/gold_pattern.png', repeat: ImageRepeat.repeat),
            ),
          ),
          StreamBuilder(
            stream: dbRef.onValue,
            builder: (context, snapshot) {
              if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
                var userData = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(height: 100),
                      // صورة البروفايل مع إضاءة حمراء
                      FadeInDown(
                        child: Center(
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Container(
                                width: 110,
                                height: 110,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(color: Colors.red.withOpacity(0.5), blurRadius: 20, spreadRadius: 5),
                                  ],
                                  border: Border.all(color: Colors.amber, width: 2),
                                ),
                              ),
                              CircleAvatar(
                                radius: 50,
                                backgroundColor: Colors.grey[900],
                                backgroundImage: CachedNetworkImageProvider(userData['profilePic'] ?? ""),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      FadeInUp(
                        child: Column(
                          children: [
                            Text(
                              userData['name'] ?? "الأهلي فوق الجميع",
                              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.2),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              "@${userData['username'] ?? 'ahly_fan'}",
                              style: TextStyle(color: Colors.amber.withOpacity(0.8), fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 25),
                      // إحصائيات تيك توك بتصميم زجاجي
                      FadeInUp(
                        delay: const Duration(milliseconds: 200),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildStatItem("متابعة", userData['following'] ?? 0),
                            _buildVerticalDivider(),
                            _buildStatItem("متابعون", userData['followers'] ?? 0),
                            _buildVerticalDivider(),
                            _buildStatItem("تسجيلات إعجاب", userData['likes'] ?? 0),
                          ],
                        ),
                      ),
                      const SizedBox(height: 25),
                      // أزرار التفاعل
                      FadeInUp(
                        delay: const Duration(milliseconds: 400),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildActionButton("تعديل الملف", Colors.amber, Colors.black, onTap: () => _editProfile()),
                            const SizedBox(width: 10),
                            _buildActionButton("مشاركة", Colors.white.withOpacity(0.1), Colors.white, onTap: () => _shareProfile()),
                          ],
                        ),
                      ),
                      const SizedBox(height: 30),
                      // عرض الأوسمة
                      FadeInUp(
                        delay: const Duration(milliseconds: 600),
                        child: _buildBadgesSection(),
                      ),
                      const SizedBox(height: 30),
                      // تبويبات الفيديوهات
                      _buildVideoTabs(user?.uid),
                    ],
                  ),
                );
              }
              return const Center(child: CircularProgressIndicator(color: Colors.red));
            },
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String title, int count) {
    return Column(
      children: [
        Text(
          "$count",
          style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildVerticalDivider() {
    return Container(
      height: 20,
      width: 1,
      color: Colors.amber.withOpacity(0.3),
      margin: const EdgeInsets.symmetric(horizontal: 25),
    );
  }

  Widget _buildActionButton(String text, Color bg, Color textColor, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap ?? () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("تم الضغط على $text"), duration: const Duration(seconds: 1)),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 12),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(8),
          boxShadow: bg == Colors.amber ? [BoxShadow(color: Colors.amber.withOpacity(0.3), blurRadius: 10)] : null,
        ),
        child: Text(
          text,
          style: TextStyle(color: textColor, fontWeight: FontWeight.bold, fontSize: 15),
        ),
      ),
    );
  }

  Widget _buildVideoTabs(String? uid) {
    return DefaultTabController(
      length: 3,
      child: Column(
        children: [
          TabBar(
            indicatorColor: Colors.red,
            indicatorWeight: 3,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white.withOpacity(0.4),
            tabs: const [
              Tab(icon: Icon(Icons.grid_on_rounded, size: 26)),
              Tab(icon: Icon(Icons.lock_outline_rounded, size: 26)),
              Tab(icon: Icon(Icons.favorite_border_rounded, size: 26)),
            ],
          ),
          SizedBox(
            height: 400,
            child: TabBarView(
              children: [
                _buildUserVideosGrid(uid),
                const Center(child: Icon(Icons.lock_outline, size: 50, color: Colors.amber)),
                const Center(child: Icon(Icons.favorite_border, size: 50, color: Colors.amber)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserVideosGrid(String? uid) {
    final reelsRef = FirebaseDatabase.instance.ref("reels").orderByChild("userId").equalTo(uid);
    return StreamBuilder(
      stream: reelsRef.onValue,
      builder: (context, snapshot) {
        if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
          var reelsMap = Map<String, dynamic>.from(snapshot.data!.snapshot.value as Map);
          var reelsList = reelsMap.values.toList();
          return GridView.builder(
            padding: const EdgeInsets.all(1),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              childAspectRatio: 0.75,
              crossAxisSpacing: 1,
              mainAxisSpacing: 1,
            ),
            itemCount: reelsList.length,
            itemBuilder: (context, index) {
              return Stack(
                fit: StackFit.expand,
                children: [
                  CachedNetworkImage(
                    imageUrl: reelsList[index]['thumbnailUrl'],
                    fit: BoxFit.cover,
                  ),
                  Positioned(
                    bottom: 5,
                    left: 5,
                    child: Row(
                      children: [
                        const Icon(Icons.play_arrow_outlined, color: Colors.white, size: 18),
                        Text(
                          "${reelsList[index]['views'] ?? 0}",
                          style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            },
          );
        }
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.video_collection_outlined, size: 60, color: Colors.white.withOpacity(0.2)),
              const SizedBox(height: 10),
              Text("لا توجد فيديوهات بعد", style: TextStyle(color: Colors.white.withOpacity(0.5))),
            ],
          ),
        );
      },
    );
  }

  void _showSearchDialog(BuildContext context) {
    // منطق البحث المتقدم
  }

  void _showNotifications(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("فتح الإشعارات...")));
  }

  void _editProfile() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("فتح تعديل الملف الشخصي...")));
  }

  void _shareProfile() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("مشاركة الملف الشخصي...")));
  }

  void _openMenu() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("فتح القائمة الجانبية...")));
  }

  Widget _buildBadgesSection() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.amber.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "⭐ الأوسمة المكتسبة",
            style: TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 15),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildBadgeItem("❤️", "مشجع وفي"),
              _buildBadgeItem("👑", "ملك التوقعات"),
              _buildBadgeItem("🦅", "نسر الريلز"),
              _buildBadgeItem("🏅", "نسر الشهر"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBadgeItem(String icon, String label) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.amber.withOpacity(0.1),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.amber.withOpacity(0.3)),
          ),
          child: Text(icon, style: const TextStyle(fontSize: 28)),
        ),
        const SizedBox(height: 8),
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11), textAlign: TextAlign.center),
      ],
    );
  }
}

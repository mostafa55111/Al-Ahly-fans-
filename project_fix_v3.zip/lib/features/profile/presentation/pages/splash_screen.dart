import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:gomhor_alahly_clean_new/core/navigation/main_navigation.dart';
import 'package:gomhor_alahly_clean_new/features/profile/presentation/pages/login_screen.dart';
import 'package:animate_do/animate_do.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
    _navigateToNext();
  }

  _navigateToNext() async {
    // مدة 3 ثواني كما طلب المستخدم
    await Future.delayed(const Duration(seconds: 3));
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    
    if (FirebaseAuth.instance.currentUser != null) {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const MainNavigation()),
        );
      }
    } else {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const LoginScreen()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // ثيم أسود
      body: Stack(
        children: [
          // زخرفة ذهبية في الخلفية
          Positioned.fill(
            child: Opacity(
              opacity: 0.1,
              child: Image.asset(
                'assets/images/gold_pattern.png',
                repeat: ImageRepeat.repeat,
              ),
            ),
          ),
          Center(
            child: FadeIn(
              duration: const Duration(milliseconds: 1500),
              child: Hero(
                tag: 'logo',
                child: Image.asset('assets/images/logo.png', width: 280),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:firebase_database/firebase_database.dart';
import 'package:al_ahly_fans_super_app/features/voting_match_center/data/models/match_model.dart';

abstract class MatchRemoteDataSource {
  Future<List<MatchModel>> getMatchSchedule();
  Future<MatchModel> getMatchDetails(String matchId);
  Future<void> submitEagleOfTheMatchVote(String matchId, String playerId, String userId);
  Future<void> submitPlayerRating(String matchId, String playerId, String userId, int rating);
  Future<void> createMatch(MatchModel match);
  Future<void> updateMatch(MatchModel match);
  Future<void> deleteMatch(String matchId);
}

class MatchRemoteDataSourceImpl implements MatchRemoteDataSource {
  final FirebaseDatabase _database;

  MatchRemoteDataSourceImpl(this._database);

  @override
  Future<List<MatchModel>> getMatchSchedule() async {
    final snapshot = await _database.ref().child('matches').get();
    if (snapshot.exists) {
      final List<MatchModel> matches = [];
      (snapshot.value as Map<dynamic, dynamic>).forEach((key, value) {
        matches.add(MatchModel.fromSnapshot(DataSnapshot(key, value, snapshot.ref)));
      });
      return matches;
    } else {
      return [];
    }
  }

  @override
  Future<MatchModel> getMatchDetails(String matchId) async {
    final snapshot = await _database.ref().child('matches/$matchId').get();
    if (snapshot.exists) {
      return MatchModel.fromSnapshot(snapshot);
    } else {
      throw Exception('Match not found');
    }
  }

  @override
  Future<void> submitEagleOfTheMatchVote(String matchId, String playerId, String userId) async {
    await _database.ref().child('matches/$matchId/eagleOfTheMatchVotes/$userId').set(playerId);
  }

  @override
  Future<void> submitPlayerRating(String matchId, String playerId, String userId, int rating) async {
    await _database.ref().child('matches/$matchId/playerRatings/$playerId/$userId').set(rating);
  }

  @override
  Future<void> createMatch(MatchModel match) async {
    final newMatchRef = _database.ref().child('matches').push();
    await newMatchRef.set(match.toJson());
  }

  @override
  Future<void> updateMatch(MatchModel match) async {
    await _database.ref().child('matches/${match.id}').update(match.toJson());
  }

  @override
  Future<void> deleteMatch(String matchId) async {
    await _database.ref().child('matches/$matchId').remove();
  }
}

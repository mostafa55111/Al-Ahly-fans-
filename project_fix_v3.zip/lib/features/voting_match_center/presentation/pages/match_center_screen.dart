import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:animate_do/animate_do.dart';
import 'package:intl/intl.dart';
import 'package:gomhor_alahly_clean_new/core/services/sports_api_service.dart';
import 'dart:async';

class MatchCenterScreen extends StatefulWidget {
  const MatchCenterScreen({super.key});

  @override
  State<MatchCenterScreen> createState() => _MatchCenterScreenState();
}

class _MatchCenterScreenState extends State<MatchCenterScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final SportsApiService _sportsApi = SportsApiService();
  late Timer _matchStatusTimer;
  Map<String, dynamic>? _currentMatch;
  bool _matchFinished = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _initializeMatchMonitoring();
  }

  /// تهيئة مراقبة حالة المباراة
  void _initializeMatchMonitoring() {
    _matchStatusTimer = Timer.periodic(const Duration(seconds: 30), (timer) async {
      final matches = await _sportsApi.getNextMatches();
      if (matches.isNotEmpty) {
        final match = matches[0];
        final status = match['status'] ?? match['strStatus'] ?? '';
        
        // التحقق من انتهاء المباراة
        if ((status.toUpperCase().contains('FINISHED') || status.toUpperCase().contains('COMPLETED')) && !_matchFinished) {
          _matchFinished = true;
          _currentMatch = match;
          _triggerVotingAfterMatch(match);
        }
      }
    });
  }

  /// تفعيل نظام التصويت بعد انتهاء المباراة
  void _triggerVotingAfterMatch(Map<String, dynamic> match) {
    if (!mounted) return;
    
    // عرض إشعار بانتهاء المباراة
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('انتهت المباراة! يمكنك الآن التصويت لرجل المباراة'),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 5),
        action: SnackBarAction(
          label: 'صوّت الآن',
          onPressed: () {
            _tabController.animateTo(1); // الانتقال إلى تبويب التصويت
          },
        ),
      ),
    );

    // حفظ بيانات المباراة المنتهية في Firebase
    _saveFinishedMatchData(match);
  }

  /// حفظ بيانات المباراة المنتهية
  void _saveFinishedMatchData(Map<String, dynamic> match) {
    final matchRef = FirebaseDatabase.instance.ref('finished_matches').push();
    matchRef.set({
      'homeTeam': match['homeTeam'] ?? match['strHomeTeam'] ?? 'فريق',
      'awayTeam': match['awayTeam'] ?? match['strAwayTeam'] ?? 'فريق',
      'score': match['score'] ?? match['intHomeScore'] ?? '0',
      'awayScore': match['awayScore'] ?? match['intAwayScore'] ?? '0',
      'date': DateTime.now().toIso8601String(),
      'status': 'انتهت',
      'votingEnabled': true,
    });
  }

  @override
  void dispose() {
    _matchStatusTimer.cancel();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Text(
          "مركز المباريات",
          style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, letterSpacing: 1.2),
        ),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.red,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white.withOpacity(0.4),
          tabs: const [
            Tab(text: "المباراة القادمة"),
            Tab(text: "التصويت"),
            Tab(text: "نسر الشهر"),
          ],
        ),
      ),
      body: Stack(
        children: [
          // زخرفة ذهبية في الخلفية
          Positioned.fill(
            child: Opacity(
              opacity: 0.05,
              child: Image.asset('assets/images/gold_pattern.png', repeat: ImageRepeat.repeat),
            ),
          ),
          TabBarView(
            controller: _tabController,
            children: [
              _buildNextMatchTab(),
              _buildVotingTab(),
              _buildEagleOfMonthTab(),
            ],
          ),
        ],
      ),
    );
  }

  /// تبويب المباراة القادمة
  Widget _buildNextMatchTab() {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: _sportsApi.getNextMatches(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.red));
        }

        if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
            child: Text(
              'لا توجد مباريات قادمة',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
          );
        }

        final match = snapshot.data![0];
        final homeTeam = match['homeTeam'] ?? match['strHomeTeam'] ?? 'فريق';
        final awayTeam = match['awayTeam'] ?? match['strAwayTeam'] ?? 'فريق';
        final matchDate = match['utcDate'] ?? match['dateEvent'] ?? '';
        final matchTime = match['strTime'] ?? '20:00';
        final league = match['competition'] ?? match['strLeague'] ?? 'دوري';
        final venue = match['venue'] ?? match['strVenue'] ?? 'ملعب';
        final status = match['status'] ?? match['strStatus'] ?? 'مجدولة';

        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              FadeInDown(
                child: Container(
                  padding: const EdgeInsets.all(25),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.red.withOpacity(0.2), Colors.black],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.amber.withOpacity(0.3)),
                  ),
                  child: Column(
                    children: [
                      // حالة المباراة
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getStatusColor(status),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          _sportsApi.getMatchStatus(status),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        "المباراة القادمة",
                        style: TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 25),
                      // الفريقان
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  homeTeam,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 8),
                                const Icon(Icons.sports_soccer, color: Colors.amber, size: 40),
                              ],
                            ),
                          ),
                          const Column(
                            children: [
                              Text(
                                "VS",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 5),
                            ],
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Text(
                                  awayTeam,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 8),
                                const Icon(Icons.sports_soccer, color: Colors.amber, size: 40),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      // التاريخ والوقت
                      Text(
                        _sportsApi.formatISODateTime(matchDate),
                        style: const TextStyle(
                          color: Colors.amber,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 15),
                      // الدوري والملعب
                      Text(
                        league,
                        style: const TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        venue,
                        style: const TextStyle(color: Colors.white54, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
              // معلومات إضافية
              FadeInUp(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "معلومات المباراة",
                      style: TextStyle(
                        color: Colors.amber,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 15),
                    _buildInfoCard(Icons.calendar_today, "التاريخ", _sportsApi.formatISODateTime(matchDate)),
                    _buildInfoCard(Icons.stadium, "الملعب", venue),
                    _buildInfoCard(Icons.sports, "الدوري", league),
                    _buildInfoCard(Icons.info, "الحالة", _sportsApi.getMatchStatus(status)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  /// بناء بطاقة معلومات
  Widget _buildInfoCard(IconData icon, String title, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.amber.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(icon, color: Colors.amber, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  /// تبويب التصويت
  Widget _buildVotingTab() {
    final playersRef = FirebaseDatabase.instance.ref("best_player");
    return StreamBuilder(
      stream: playersRef.onValue,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(color: Colors.red));
        }

        if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
          final dynamic data = snapshot.data!.snapshot.value;
          if (data is Map) {
            var playersMap = Map<String, dynamic>.from(data.cast<String, dynamic>());
            var playersList = playersMap.values.toList();
            
            return Column(
              children: [
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    "صوّت لنسر المباراة",
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 15),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.7,
                      crossAxisSpacing: 15,
                      mainAxisSpacing: 15,
                    ),
                    itemCount: playersList.length,
                    itemBuilder: (context, index) {
                      return _buildFifaCard(Map<String, dynamic>.from(playersList[index]));
                    },
                  ),
                ),
              ],
            );
          }
        }
        
        return const Center(
          child: Text(
            "لا توجد بيانات تصويت حالياً",
            style: TextStyle(color: Colors.white70),
          ),
        );
      },
    );
  }

  /// بطاقة لاعب FIFA
  Widget _buildFifaCard(Map<String, dynamic> player) {
    return FadeInUp(
      child: GestureDetector(
        onTap: () => _showVoteConfirmation(player),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [BoxShadow(color: Colors.amber.withOpacity(0.1), blurRadius: 10)],
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // صورة كارت فيفا
              ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: CachedNetworkImage(
                  imageUrl: player['cardUrl'] ?? 'https://via.placeholder.com/200',
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(color: Colors.grey[900]),
                  errorWidget: (context, url, error) => Container(
                    color: Colors.grey[900],
                    child: const Icon(Icons.person, color: Colors.amber),
                  ),
                ),
              ),
              // تأثير الإضاءة
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    gradient: LinearGradient(
                      colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              // معلومات اللاعب
              Positioned(
                bottom: 15,
                left: 0,
                right: 0,
                child: Column(
                  children: [
                    Text(
                      player['name'] ?? 'لاعب',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 5),
                    const Text(
                      "اضغط للتصويت",
                      style: TextStyle(color: Colors.amber, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// تأكيد التصويت
  void _showVoteConfirmation(Map<String, dynamic> player) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.grey[900],
        title: const Text(
          'تأكيد التصويت',
          style: TextStyle(color: Colors.amber),
        ),
        content: Text(
          'هل تريد التصويت لـ ${player['name']}؟',
          style: const TextStyle(color: Colors.white),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () {
              _submitVote(player);
              Navigator.pop(context);
            },
            child: const Text('تصويت', style: TextStyle(color: Colors.amber)),
          ),
        ],
      ),
    );
  }

  /// إرسال التصويت
  void _submitVote(Map<String, dynamic> player) {
    final playerId = player['id'] ?? player['name'];
    final votesRef = FirebaseDatabase.instance.ref("best_player/$playerId/votes");
    
    votesRef.get().then((snapshot) {
      final currentVotes = (snapshot.value as int?) ?? 0;
      votesRef.set(currentVotes + 1).then((_) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('شكراً! تم تسجيل تصويتك لـ ${player['name']}'),
            backgroundColor: Colors.green,
          ),
        );
      });
    });
  }

  /// تبويب نسر الشهر
  Widget _buildEagleOfMonthTab() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ZoomIn(
            child: Container(
              width: 250,
              height: 350,
              decoration: BoxDecoration(
                boxShadow: [
                  BoxShadow(
                    color: Colors.amber.withOpacity(0.4),
                    blurRadius: 30,
                    spreadRadius: 5,
                  )
                ],
              ),
              child: Image.asset('assets/images/eagle_of_month_card.png'),
            ),
          ),
          const SizedBox(height: 30),
          const Text(
            "نسر الشهر",
            style: TextStyle(
              color: Colors.amber,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            "محمد الشناوي",
            style: TextStyle(color: Colors.white, fontSize: 20),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.amber.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.amber.withOpacity(0.3)),
            ),
            child: const Text(
              'أفضل لاعب في الشهر الحالي',
              style: TextStyle(color: Colors.amber, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }

  /// الحصول على لون حالة المباراة
  Color _getStatusColor(String status) {
    final upperStatus = status.toUpperCase();
    if (upperStatus.contains('FINISHED') || upperStatus.contains('COMPLETED')) {
      return Colors.grey;
    } else if (upperStatus.contains('IN_PLAY') || upperStatus.contains('IN PLAY')) {
      return Colors.green;
    } else if (upperStatus.contains('SCHEDULED')) {
      return Colors.blue;
    } else if (upperStatus.contains('POSTPONED')) {
      return Colors.orange;
    }
    return Colors.grey;
  }
}

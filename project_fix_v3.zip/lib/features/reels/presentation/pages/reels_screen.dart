import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:animate_do/animate_do.dart';
import 'package:share_plus/share_plus.dart';
import 'package:gal/gal.dart';
import 'package:gomhor_alahly_clean_new/features/search/presentation/pages/ai_chat_screen.dart';
import 'dart:ui';

class ReelsScreen extends StatefulWidget {
  const ReelsScreen({super.key});

  @override
  State<ReelsScreen> createState() => _ReelsScreenState();
}

class _ReelsScreenState extends State<ReelsScreen> {
  final PageController _pageController = PageController();

  @override
  Widget build(BuildContext context) {
    final reelsRef = FirebaseDatabase.instance.ref("Reels");

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.search, color: Colors.amber, size: 28),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiChatScreen()),
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add_circle_outline, color: Colors.red, size: 28),
            onPressed: () {},
          ),
        ],
      ),
      body: StreamBuilder(
        stream: reelsRef.onValue,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.red));
          }

          if (snapshot.hasError) {
            return Center(child: Text('خطأ في الاتصال: ${snapshot.error}', style: const TextStyle(color: Colors.white)));
          }

          if (snapshot.hasData && snapshot.data!.snapshot.value != null) {
            try {
              final dynamic data = snapshot.data!.snapshot.value;
              List<dynamic> reelsList = [];
              
              if (data is Map) {
                reelsList = data.values.toList();
              } else if (data is List) {
                reelsList = data.where((e) => e != null).toList();
              }

              if (reelsList.isEmpty) {
                return const Center(child: Text('لا توجد فيديوهات حالياً', style: TextStyle(color: Colors.white)));
              }
            
              return PageView.builder(
                controller: _pageController,
                scrollDirection: Axis.vertical,
                itemCount: reelsList.length,
                itemBuilder: (context, index) {
                  final reelData = reelsList[index];
                  if (reelData is Map) {
                    return ReelItem(
                      key: ValueKey(reelData['videoUrl'] ?? index.toString()),
                      reelData: Map<String, dynamic>.from(reelData.cast<String, dynamic>())
                    );
                  }
                  return const SizedBox();
                },
              );
            } catch (e) {
              return Center(child: Text('خطأ في معالجة البيانات: $e', style: const TextStyle(color: Colors.white)));
            }
          }
          
          return const Center(child: Text('لا توجد بيانات متاحة', style: TextStyle(color: Colors.white)));
        },
      ),
    );
  }
}

class ReelItem extends StatefulWidget {
  final Map<String, dynamic> reelData;
  const ReelItem({super.key, required this.reelData});

  @override
  State<ReelItem> createState() => _ReelItemState();
}

class _ReelItemState extends State<ReelItem> with SingleTickerProviderStateMixin {
  late VideoPlayerController _controller;
  bool _isInitialized = false;
  bool _showHeartOverlay = false;
  late AnimationController _heartAnimController;

  @override
  void initState() {
    super.initState();
    _heartAnimController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    final videoUrl = widget.reelData['videoUrl'] ?? '';
    if (videoUrl.isNotEmpty) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _isInitialized = true;
              _controller.setLooping(true);
              _controller.play();
            });
          }
        }).catchError((error) {
          print('خطأ في تحميل الفيديو: $error');
        });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    _heartAnimController.dispose();
    super.dispose();
  }

  void _onDoubleTap() {
    setState(() => _showHeartOverlay = true);
    _heartAnimController.forward(from: 0).then((_) {
      setState(() => _showHeartOverlay = false);
    });
    _likeVideo();
  }

  void _likeVideo() async {
    final videoId = widget.reelData['id'] ?? widget.reelData['videoUrl'].hashCode.toString();
    final likesRef = FirebaseDatabase.instance.ref("reels/$videoId/likes");
    final snapshot = await likesRef.get();
    final currentLikes = (snapshot.value as int?) ?? 0;
    await likesRef.set(currentLikes + 1);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // مشغل الفيديو
        _isInitialized
            ? GestureDetector(
                onDoubleTap: _onDoubleTap,
                onTap: () {
                  setState(() {
                    _controller.value.isPlaying ? _controller.pause() : _controller.play();
                  });
                },
                child: VideoPlayer(_controller),
              )
            : Container(
                color: Colors.black,
                child: const Center(child: CircularProgressIndicator(color: Colors.red)),
              ),
        
        // العلامة المائية (اسم المستخدم + نسر الأهلي)
        Positioned(
          top: 60,
          left: 20,
          child: FadeInLeft(
            child: Row(
              children: [
                Image.asset('assets/images/eagle_watermark.png', width: 30, color: Colors.white.withOpacity(0.5)),
                const SizedBox(width: 8),
                Text(
                  widget.reelData['userName'] ?? "جمهور الأهلي",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.1,
                  ),
                ),
              ],
            ),
          ),
        ),

        // أزرار التفاعل الجانبية (تيك توك ستايل)
        Positioned(
          right: 15,
          bottom: 100,
          child: Column(
            children: [
              _buildUserAvatar(widget.reelData['userProfilePic']),
              const SizedBox(height: 25),
              _buildActionButton(Icons.favorite_rounded, widget.reelData['likes']?.toString() ?? "0", Colors.red),
              const SizedBox(height: 20),
              _buildActionButton(Icons.comment_rounded, widget.reelData['comments']?.toString() ?? "0", Colors.white),
              const SizedBox(height: 20),
              _buildActionButton(Icons.share_rounded, "مشاركة", Colors.white, onTap: () { if (widget.reelData["videoUrl"] != null) Share.share(widget.reelData["videoUrl"]); }),
              const SizedBox(height: 20),
              _buildActionButton(Icons.download_for_offline_rounded, "تحميل", Colors.amber, onTap: () { if (widget.reelData["videoUrl"] != null) _downloadVideo(); }),
            ],
          ),
        ),

        // معلومات الفيديو في الأسفل
        Positioned(
          left: 15,
          bottom: 40,
          right: 80,
          child: FadeInUp(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "@${widget.reelData['userName'] ?? 'ahly_fan'}",
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                ),
                const SizedBox(height: 10),
                Text(
                  widget.reelData['caption'] ?? "الأهلي فوق الجميع 🦅❤️",
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 15),
                Row(
                  children: [
                    const Icon(Icons.music_note_rounded, color: Colors.white, size: 16),
                    const SizedBox(width: 5),
                  Text("صوت أصلي - ${widget.reelData["userName"] ?? "غير معروف"}", style: const TextStyle(color: Colors.white, fontSize: 13)),             ],
                ),
              ],
            ),
          ),
        ),

        // تأثير القلب عند النقر المزدوج
        if (_showHeartOverlay)
          Center(
            child: ZoomIn(
              duration: const Duration(milliseconds: 400),
              child: const Icon(Icons.favorite, color: Colors.red, size: 120),
            ),
          ),
      ],
    );
  }

  Widget _buildUserAvatar(String? url) {
    return Stack(
      alignment: Alignment.bottomCenter,
      clipBehavior: Clip.none,
      children: [
        Container(
          padding: const EdgeInsets.all(2),
          decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
          child: CircleAvatar(
            radius: 25,
            backgroundImage: CachedNetworkImageProvider(url ?? "https://via.placeholder.com/150"), // صورة افتراضية للملف الشخصي
          ),
        ),
        Positioned(
          bottom: -10,
          child: Container(
            decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
            child: const Icon(Icons.add, color: Colors.white, size: 20),
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(IconData icon, String label, Color color, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: color, size: 38, shadows: [Shadow(color: Colors.black.withOpacity(0.5), blurRadius: 10)]),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Future<void> _downloadVideo() async {
    final videoUrl = widget.reelData['videoUrl'];
    if (videoUrl == null) return;

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("جاري التحميل...")));
    try {
      await Gal.putVideo(videoUrl);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("تم حفظ الفيديو في المعرض")));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("خطأ في التحميل: $e")));
      }
    }
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:gomhor_alahly_clean_new/core/theme/app_theme.dart';
import 'package:gomhor_alahly_clean_new/features/social_feed/presentation/bloc/social_feed_bloc.dart';
import 'package:gomhor_alahly_clean_new/features/social_feed/presentation/bloc/social_feed_event.dart';
import 'package:gomhor_alahly_clean_new/features/social_feed/presentation/bloc/social_feed_state.dart';
import 'package:gomhor_alahly_clean_new/features/social_feed/presentation/widgets/post_card_widget.dart';

/// شاشة الفيد الاجتماعي
/// تعرض منشورات المشجعين مع التفاعلات
class SocialFeedScreen extends StatefulWidget {
  const SocialFeedScreen({Key? key}) : super(key: key);

  @override
  State<SocialFeedScreen> createState() => _SocialFeedScreenState();
}

class _SocialFeedScreenState extends State<SocialFeedScreen> {
  late ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
    _scrollController.addListener(_onScroll);
    
    // تحميل المنشورات عند فتح الشاشة
    context.read<SocialFeedBloc>().add(
      const LoadFeedPostsEvent(isRefresh: true),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  /// معالج التمرير - تحميل المزيد عند الوصول للنهاية
  void _onScroll() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      context.read<SocialFeedBloc>().add(const LoadMorePostsEvent());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.darkBlack,
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: () async {
          context.read<SocialFeedBloc>().add(
            const LoadFeedPostsEvent(isRefresh: true),
          );
        },
        color: AppColors.luminousGold,
        backgroundColor: AppColors.darkBlack,
        child: BlocBuilder<SocialFeedBloc, SocialFeedState>(
          builder: (context, state) {
            if (state is SocialFeedLoading) {
              return const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppColors.luminousGold,
                  ),
                ),
              );
            }

            if (state is SocialFeedError) {
              return _buildErrorWidget(state.message);
            }

            if (state is SocialFeedEmpty) {
              return _buildEmptyWidget();
            }

            if (state is SocialFeedLoaded) {
              return ListView.builder(
                controller: _scrollController,
                itemCount: state.posts.length + (state.isLastPage ? 0 : 1),
                itemBuilder: (context, index) {
                  if (index == state.posts.length) {
                    return const Padding(
                      padding: EdgeInsets.all(16),
                      child: Center(
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppColors.luminousGold,
                          ),
                        ),
                      ),
                    );
                  }

                  final post = state.posts[index];
                  return PostCardWidget(
                    post: post,
                    onLike: (postId) {
                      context.read<SocialFeedBloc>().add(
                        LikePostEvent(postId),
                      );
                    },
                    onUnlike: (postId) {
                      context.read<SocialFeedBloc>().add(
                        UnlikePostEvent(postId),
                      );
                    },
                    onComment: (postId) {
                      _showCommentBottomSheet(context, postId);
                    },
                    onShare: (postId) {
                      _showShareBottomSheet(context, postId);
                    },
                    onPostTap: (postId) {
                      _navigateToPostDetails(context, postId);
                    },
                  );
                },
              );
            }

            return const SizedBox();
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _navigateToCreatePost(context),
        backgroundColor: AppColors.luminousGold,
        child: const Icon(
          Icons.add,
          color: AppColors.darkBlack,
        ),
      ),
    );
  }

  /// بناء شريط التطبيق
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: AppColors.darkBlack,
      elevation: 0,
      title: const Text(
        'الفيد الاجتماعي',
        style: TextStyle(
          color: AppColors.luminousGold,
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      centerTitle: true,
      actions: [
        IconButton(
          icon: const Icon(Icons.search, color: AppColors.luminousGold),
          onPressed: () => _navigateToSearch(context),
        ),
        IconButton(
          icon: const Icon(Icons.notifications, color: AppColors.luminousGold),
          onPressed: () => _navigateToNotifications(context),
        ),
      ],
    );
  }

  /// بناء widget الخطأ
  Widget _buildErrorWidget(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            color: AppColors.luminousGold,
            size: 48,
          ),
          const SizedBox(height: 16),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              context.read<SocialFeedBloc>().add(
                const LoadFeedPostsEvent(isRefresh: true),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.luminousGold,
            ),
            child: const Text(
              'إعادة المحاولة',
              style: TextStyle(color: AppColors.darkBlack),
            ),
          ),
        ],
      ),
    );
  }

  /// بناء widget الفراغ
  Widget _buildEmptyWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.inbox,
            color: AppColors.luminousGold,
            size: 48,
          ),
          const SizedBox(height: 16),
          const Text(
            'لا توجد منشورات حالياً',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'ابدأ بمتابعة المشجعين الآخرين',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  /// عرض نافذة التعليقات
  void _showCommentBottomSheet(BuildContext context, String postId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'التعليقات',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                hintText: 'أضف تعليقاً...',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF2A2A2A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
              ),
              style: const TextStyle(color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  /// عرض نافذة المشاركة
  void _showShareBottomSheet(BuildContext context, String postId) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A1A1A),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'مشاركة المنشور',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildShareOption('WhatsApp', Icons.chat),
                _buildShareOption('نسخ الرابط', Icons.link),
                _buildShareOption('مشاركة مباشرة', Icons.person),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// بناء خيار المشاركة
  Widget _buildShareOption(String label, IconData icon) {
    return Column(
      children: [
        Icon(icon, color: AppColors.luminousGold, size: 32),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(color: Colors.white, fontSize: 12),
        ),
      ],
    );
  }

  /// الانتقال لشاشة إنشاء منشور
  void _navigateToCreatePost(BuildContext context) {
    // سيتم تطبيقها لاحقاً
  }

  /// الانتقال لشاشة البحث
  void _navigateToSearch(BuildContext context) {
    // سيتم تطبيقها لاحقاً
  }

  /// الانتقال لشاشة الإشعارات
  void _navigateToNotifications(BuildContext context) {
    // سيتم تطبيقها لاحقاً
  }

  /// الانتقال لتفاصيل المنشور
  void _navigateToPostDetails(BuildContext context, String postId) {
    // سيتم تطبيقها لاحقاً
  }
}
